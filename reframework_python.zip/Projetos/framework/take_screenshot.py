import sys
import os
from datetime import datetime
from utils.config import log_error, log_info, configure_logging

configure_logging()

def take_screenshot(driver, folder=None):
    """
    Tira um screenshot da tela atual do navegador.

    Args:
        driver: Instância do navegador (Selenium WebDriver).
        folder (str): Diretório para salvar as capturas de tela.
    """
    if folder is None:
        # Definir pasta de logs no mesmo diretório do executável
        base_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(__file__)
        folder = os.path.join(base_dir, '..', "logs", "screenshots")
    
    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    screenshot_path = os.path.join(folder, f"screenshot_{timestamp}.png")

    try:
        driver.save_screenshot(screenshot_path)
        log_info(f"Screenshot tirado e salvo em: {screenshot_path}")
    except Exception as e:
        log_error(f"Erro ao tirar screenshot: {e}")
