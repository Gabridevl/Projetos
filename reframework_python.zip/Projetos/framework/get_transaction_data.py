import logging
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from components.verificacoes import valida_elemento_visivel
from utils.config import log_info, log_error, configure_logging
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

configure_logging()

DESIRED_FLOWS = [
    "CONTRATO - MODELO",
    "CONTRATO - Dinamico Sistema",
    "CONTRATO - Identifica Dinamico",
    "CONTRATO - Dinamico Intranet"
]

TABELA_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_GVTodoWork']"
TITULO_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_titleLabel']"

def get_transaction_data(driver):
    """
    Obtém os dados das transações disponíveis na tabela.

    Args:
        driver: Instância do WebDriver do Selenium.

    Returns:
        str | None: Nome do fluxo encontrado ou None caso não encontre.
    """
    driver.refresh()

    # Verificar visibilidade da tabela antes de tentar extrair dados
    if valida_elemento_visivel(driver, TABELA_XPATH, 5):
        tabela = driver.find_element(By.XPATH, TABELA_XPATH)
        tbody = tabela.find_element(By.TAG_NAME, "tbody")
        linhas = tbody.find_elements(By.XPATH, ".//tr[contains(@class, 'gridControlTableRow') or contains(@class, 'gridControlTableAlternatingRow')]")
        
        # Procurar fluxos específicos primeiro
        for fluxo_nome in ["CONTRATO - Página 1", "CONTRATO - REDIGITAÇÃO NCONTRATO"]:
            fluxo_result = procurar_fluxo(linhas, fluxo_nome)
            if fluxo_result:
                return fluxo_result

        # Procurar fluxos desejados em caso de não encontrar fluxos específicos
        fluxo_desejado = procurar_fluxo(linhas, DESIRED_FLOWS, multiple=True)
        if fluxo_desejado:
            return fluxo_desejado

        log_info("Nenhum fluxo desejado encontrado na tabela.")
        return None
    else:
        # Caso a tabela não esteja visível, tenta pegar o título da página
        try:
            titulo = driver.find_element(By.XPATH, TITULO_XPATH).text.replace('CONTRATO - BPO - ', '')
            return titulo
        except NoSuchElementException:
            log_error("Título não encontrado. Retornando None.")
            return None

def procurar_fluxo(linhas, fluxo_nome, multiple=False):
    """
    Procura um fluxo na tabela de transações.

    Args:
        linhas (list): Lista de linhas da tabela.
        fluxo_nome (str | list): Nome ou lista de nomes de fluxos a serem procurados.
        multiple (bool): Se True, permite buscar múltiplos fluxos.

    Returns:
        str | None: Nome do fluxo encontrado ou None.
    """
    if isinstance(fluxo_nome, str):
        fluxo_nome = [fluxo_nome]  # Garantir que fluxo_nome seja uma lista, mesmo que seja uma string

    for linha in linhas:
        colunas = linha.find_elements(By.TAG_NAME, "td")
        if len(colunas) >= 3:
            nome_fluxo = colunas[1].text.strip()
            if (multiple and nome_fluxo in fluxo_nome) or nome_fluxo == fluxo_nome[0]:
                return processar_fluxo(linha, nome_fluxo)
    return None

def processar_fluxo(linha, fluxo_nome):
    """
    Processa o fluxo e tenta clicar no botão correspondente.

    Args:
        linha: A linha da tabela contendo o fluxo.
        fluxo_nome: O nome do fluxo.

    Returns:
        str | None: Nome do fluxo se processado com sucesso, ou None em caso de falha.
    """
    try:
        botao_fluxo = linha.find_element(By.XPATH, ".//input[contains(@id,'buttonCommandSelectTask')]")
        botao_fluxo.click()
        log_info(f"Fluxo '{fluxo_nome}' processado com sucesso.")
        return fluxo_nome
    except (NoSuchElementException, TimeoutException) as e:
        log_error(f"Erro ao tentar abrir o fluxo '{fluxo_nome}': {e}")
        return None
