import os
import psutil

def kill_all_process(process_name="msedge.exe"):
    """Finaliza todos os processos com o nome especificado."""
    for proc in psutil.process_iter(attrs=['pid', 'name']):
        try:
            if proc.info['name'].lower() == process_name.lower():
                os.kill(proc.info['pid'], 9)  # Força a finalização do processo
                print(f"Processo {process_name} (PID {proc.info['pid']}) finalizado.")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass  # Ignora erros caso o processo tenha sido finalizado ou o acesso tenha sido negado

def end_process(driver):
    """Finaliza o processo do driver, se estiver em execução."""
    if driver is not None:
        try:
            driver.quit()
            print("Driver finalizado com sucesso.")
        except Exception as e:
            print(f"Erro ao finalizar o driver: {e}")
