from components.login import realizar_login
from components.abrir_navegador import abrir_navegador
from components.verificacoes import valida_elemento_visivel
from utils.config import log_info, log_error, configure_logging

configure_logging()

def iniciar_driver(config):
    """Inicializa o navegador e realiza login, caso o driver não esteja presente."""
    try:
        if config.get("driver") is None:
            log_info("Iniciando o navegador e realizando login.")
            driver = abrir_navegador(config["url"])
            if driver is None:
                raise Exception("Falha ao iniciar o navegador.")
            if not realizar_login(driver, config["username"], config["password"]):
                raise Exception("Falha no login.")
            config["driver"] = driver
            log_info("Login realizado com sucesso.")
        return config
    except Exception as e:
        log_error(f"Erro ao iniciar o navegador: {e}")
        return None

def validar_elementos_essenciais(driver):
    """Valida a presença dos elementos essenciais na página."""
    try:
        tabela_existe = valida_elemento_visivel(driver, "//*[@id='ctl00_ContentPlaceHolder1_GVTodoWork']", 5)
        titulo_existe = valida_elemento_visivel(driver, "//*[@id='ctl00_ContentPlaceHolder1_titleLabel']", 5)

        if not tabela_existe:
            log_error("Tabela de transações não encontrada.")
        if not titulo_existe:
            log_error("Título não encontrado.")
        
        return tabela_existe and titulo_existe
    except Exception as e:
        log_error(f"Erro ao validar elementos essenciais: {e}")
        return False

def init(config):
    """
    Inicializa o navegador e verifica a presença dos elementos essenciais na página.

    Args:
        config (dict): Dicionário de configuração com informações como driver, url, username e password.

    Returns:
        dict | None: Retorna o config atualizado com o driver ativo ou None se a inicialização falhar.
    """
    try:
        # Inicializar o driver
        config = iniciar_driver(config)
        if not config:
            return None
        
        # Verificar presença de elementos essenciais
        driver = config.get("driver")
        if not validar_elementos_essenciais(driver):
            log_error("Elementos essenciais não encontrados. Encerrando inicialização.")
            return None

        return config

    except Exception as e:
        log_error(f"Erro na inicialização: {e}")
        return None
