import asyncio
import aiohttp
from components.verificacoes import valida_elemento_visivel
from components.fluxos import processar_fluxo
from utils.config import log_error, log_info, configure_logging

configure_logging()

# Funções de verificação
def verificar_proximo_documento(driver):
    """Verifica se existe o próximo documento para processar."""
    return valida_elemento_visivel(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_Button_NextDocument')]", 10)

def verificar_tabela_transacoes(driver):
    """Verifica se a tabela de transações está presente."""
    return valida_elemento_visivel(driver, "//*[@id='ctl00_ContentPlaceHolder1_GVTodoWork']", 5)

def verificar_tela_processamento(driver):
    """Verifica se a tela de processamento está presente."""
    return valida_elemento_visivel(driver, "//*[@id='ctl00_ContentPlaceHolder1_titleLabel']", 5)

async def process_transaction(transaction_item, config, max_retries=3):
    """
    Processa uma transação, continuando para o próximo documento se disponível.
    
    Args:
        transaction_item (str): Identificador do item de transação a ser processado.
        config (dict): Configuração contendo o driver do navegador.
        max_retries (int): Número máximo de tentativas para chamar a API em caso de erro.
    """
    driver = config["driver"]
    log_info(f"Iniciando o fluxo para: {transaction_item}")
    url_servico = "https://apiSbk.sbk.com.br/process-validation-log"
    retries = 0

    async with aiohttp.ClientSession() as session:
        while True:
            _, payload = await processar_fluxo(driver, transaction_item)
            log_info(f"Fluxo {transaction_item} concluído")
            
            # Tentativa de chamar a API
            while retries < max_retries:
                try:
                    async with session.post(url_servico, json=payload) as response:  
                        response.raise_for_status()  # Levanta um erro se a resposta não for OK (200-299)
                        log_info(f"Resposta da API: {await response.json()}")
                        break  # Sai do loop de tentativas se a chamada for bem-sucedida
                except aiohttp.ClientError as e:
                    retries += 1
                    log_error(f"Erro ao chamar a API (Tentativa {retries}/{max_retries}): {e}")
                    if retries >= max_retries:
                        log_error("Número máximo de tentativas de chamada à API atingido. Abortando...")
                        return  # Sai da função em caso de falha contínua

            # Verificar condições de fluxo
            if verificar_proximo_documento(driver):
                log_info("Próximo documento encontrado, continuando...")
                await asyncio.sleep(1)  # Aguarda 1 segundo antes de tentar novamente
                continue
            elif verificar_tabela_transacoes(driver):
                log_info("Tabela de transações encontrada, finalizando fluxo.")
                break
            elif verificar_tela_processamento(driver):
                log_info("Tela de processamento identificada, continuando...")
                await asyncio.sleep(1)  # Aguarda 1 segundo antes de tentar novamente
                continue
            else:
                log_info("Nenhum próximo documento ou tabela de transações encontrada. Finalizando fluxo.")
                break

    return
