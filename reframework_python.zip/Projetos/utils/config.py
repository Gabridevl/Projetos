import json
import logging
import os
import sys

def obter_caminho_base():
    """Obtém o caminho base da aplicação, lidando com empacotamento via PyInstaller."""
    return sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(__file__)

def load_config():
    """Carrega o arquivo de configuração JSON."""
    try:
        base_path = obter_caminho_base()
        config_path = os.path.join(base_path, '..', 'data', 'config.json')

        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Arquivo de configuração não encontrado: {config_path}")
        
        with open(config_path, 'r') as config_file:
            config = json.load(config_file)

        # Validação de configurações
        if not isinstance(config.get("ativar_log"), bool):
            raise ValueError("'ativar_log' deve ser um booleano.")

        return config
    except (FileNotFoundError, ValueError, json.JSONDecodeError) as e:
        print(f"Erro ao carregar configuração: {e}")
        return {}

def configure_logging():
    """Configura o logging conforme as definições no arquivo de configuração."""
    config = load_config()

    try:
        if config.get("ativar_log", False):  # Verifica se ativar_log está setado como True
            base_path = obter_caminho_base()
            log_dir = os.path.join(base_path, '..', 'logs')
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, 'robo.log')

            # Nível de log configurável
            log_level = config.get("nivel_log", "INFO").upper()
            level = getattr(logging, log_level, logging.INFO)

            # Configuração do log
            logging.basicConfig(
                filename=log_file,
                level=level,
                format='%(asctime)s - %(levelname)s - %(message)s'
            )
            logging.info("Log ativado.")
        else:
            logging.basicConfig(level=logging.CRITICAL)
            print("Log desativado.")
    except Exception as e:
        print(f"Erro ao configurar o log: {e}")

def log_info(message):
    """Log de informações."""
    if logging.getLogger().hasHandlers():
        logging.info(message)
    else:
        print(f"INFO: {message}")  # Exibe diretamente se o log não estiver configurado

def log_error(message):
    """Log de erros."""
    if logging.getLogger().hasHandlers():
        logging.error(message)
    else:
        print(f"ERROR: {message}")  # Exibe diretamente se o log não estiver configurado
