import asyncio
from components.abrir_navegador import abrir_navegador
from components.login import realizar_login
from components.verificacoes import verificar_disponibilidade_portal, limpar_pasta_downloads
from framework.init import init
from framework.get_transaction_data import get_transaction_data
from framework.process_transaction import process_transaction
from framework.kill_all_process import kill_all_process, end_process
from framework.take_screenshot import take_screenshot
from utils.config import load_config, log_error, log_info, configure_logging

configure_logging()

async def aguardar_novas_transacoes(config):
    log_info("Não há transações a serem processadas.")
    wait_time_in_minutes = config.get("wait_time_in_minutes", 2)
    log_info(f"Esperando por {wait_time_in_minutes} minutos antes de reavaliar.")
    await asyncio.sleep(wait_time_in_minutes * 60)

    if config.get("driver"):
        end_process(config["driver"])
    kill_all_process()
    log_info("Reiniciando o processo após 5 minutos.")

async def processar_transacoes(config):
    driver = config['driver']
    while True:
        transaction_item = get_transaction_data(driver)
        if transaction_item is None:
            await aguardar_novas_transacoes(config)
            break
        try:
            await asyncio.sleep(2)  # Pequeno atraso antes de processar
            limpar_pasta_downloads()
            await process_transaction(transaction_item, config)
        except Exception as e:
            log_error(f"Erro ao processar transação '{transaction_item}'")
            take_screenshot(driver)
        break  # Processamento de uma transação por iteração principal

async def main():
    config = load_config()
    kill_all_process()  # Garante que processos antigos estão encerrados

    try:
        while True:
            # Inicialização do driver e verificação de disponibilidade do portal
            driver = config.get('driver')
            if not driver or not verificar_disponibilidade_portal(driver):
                if driver:
                    driver.quit()
                config['driver'] = abrir_navegador(config['url'])
                if not config['driver']:
                    log_error("Erro ao abrir navegador. Tentando novamente após aguardar.")
                    await aguardar_novas_transacoes(config)
                    continue

                if not realizar_login(config['driver'], config['username'], config['password']):
                    log_error("Falha no login. Tentando novamente após aguardar.")
                    await aguardar_novas_transacoes(config)
                    continue

            # Inicializa transações e verifica se há algo a processar
            if init(config) is None:
                await aguardar_novas_transacoes(config)
                continue

            # Processamento de transações
            await processar_transacoes(config)

    finally:
        # Finaliza processos no término do programa
        if config.get("driver"):
            end_process(config["driver"])
        kill_all_process()

if __name__ == "__main__":
    asyncio.run(main())