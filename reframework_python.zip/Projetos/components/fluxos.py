import re
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.action_chains import ActionChains
from components.valida_modelo import validar_modelos
from components.verificacoes import is_error_popup_present, tratar_erro, calcula_digito_verificador 
from components.request_ai import processar_requisicao
from utils.config import log_error, log_info, configure_logging

configure_logging()

NEXT_BUTTON_XPATH = "//*[contains(@id,'ctl00_ContentPlaceHolder1_Button_NextDocument')]"
CANCELAR_BUTTON_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_Button_ValidationCancel']"
DOWNLOAD_BUTTON_XPATH = "//*[contains(@id, 'ImageButtonDownload')]"

# Função genérica para preencher campos
def preencher_campo(driver, xpath, valor):
    try:
        campo = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        campo.clear()
        campo.send_keys(valor)
    except (NoSuchElementException, TimeoutException) as e:
        log_error(f"Erro ao preencher o campo {xpath}: {valor}")
        raise

# Função genérica para clicar em elementos
def clicar_elemento(driver, xpath):
    try:
        elemento = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        elemento.click()
    except (NoSuchElementException, TimeoutException) as e:
        log_error(f"Erro ao clicar no elemento {xpath}")
        raise

# Função para clicar após hover
def clicar_elemento_com_hover(driver, xpath_hover, xpath_click, tentativas=3):
    for tentativa in range(tentativas):
        try:
            elemento_hover = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, xpath_hover))
            )
            actions = ActionChains(driver)
            actions.move_to_element(elemento_hover).perform()

            elemento_click = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, xpath_click))
            )
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath_click)))
            elemento_click.click()
            return  # Sai da função se o clique for bem-sucedido
        except (NoSuchElementException, TimeoutException) as e:
            log_error(f"Erro ao clicar no elemento {xpath_click} após hover em {xpath_hover} - Tentativa {tentativa + 1} de {tentativas}")
            if tentativa == tentativas - 1:  # Se for a última tentativa, levanta o erro
                raise
            time.sleep(2 * (tentativa + 1))  # Tempo de espera incremental

# Função para validar a confiança de um campo
def is_confiavel(confianca, threshold=90):
    return confianca >= threshold

# Função para processar valores e converter para float
def parse_valor(valor):
    try:
        return float(str(valor).replace('.', '').replace(',', '.'))
    except ValueError:
        return 0  # Valor inválido ou não numérico

def verificar_fluxo(resultado, conta, cpf_cnpj, n_contrato, confianca_threshold=90, limite_valor=100000000):
    confianca_conta = resultado.get('confianca_conta', 0)
    confianca_cpf_cnpj = resultado.get('confianca_cpf_cnpj', 0)
    confianca_n_contrato = resultado.get('confianca_n_documento', 0)
    confianca_valor = resultado.get('confianca_valor', 0)

    valor = parse_valor(resultado.get('valor', 0))

    conta_usar = conta if is_confiavel(confianca_conta) else ''
    cpf_cnpj_usar = cpf_cnpj if is_confiavel(confianca_cpf_cnpj) else ''
    n_contrato_usar = n_contrato if is_confiavel(confianca_n_contrato) else ''

    if valor >= limite_valor and is_confiavel(confianca_valor):
        log_error("Valor acima do limite, redirecionando para erro.")
        return False, conta_usar, cpf_cnpj_usar, n_contrato_usar

    if not any([conta_usar, cpf_cnpj_usar, n_contrato_usar]):
        return False, conta_usar, cpf_cnpj_usar, n_contrato_usar

    return True, conta_usar, cpf_cnpj_usar, n_contrato_usar

# Função genérica para processo de fluxo
async def processar_fluxo_generico(driver, fluxo_func, codigo_erro):
    try:
        clicar_elemento_com_hover(driver, "//*[contains(@id, 'imgAdvancedImageControl')]", DOWNLOAD_BUTTON_XPATH)

        resultado, base64_image = await processar_requisicao(fluxo_func.prompt, driver)
        payload_servico = {
            "base64": base64_image,
            "payload": resultado,
            "validacao": False
        }

        if resultado and 'retorno' not in resultado:
            status = fluxo_func(driver, resultado)
            if status == "sucesso":
                payload_servico["validacao"] = True
                return True, payload_servico
            elif status == "erro_modelo":
                codigo_erro = '6'
            else:
                log_info("Erro no fluxo, encaminhando para supervisão.")
        else:
            log_error("Nenhum resultado encontrado.")
    except Exception as e:
        log_error(f"Erro durante processamento do fluxo: {str(e)}")
        raise
    
    tratar_erro(driver, codigo_erro)
    return False, payload_servico

#Fluxo genérico de clique verificação de erro
def valida_formulario(driver):
    clicar_elemento(driver, NEXT_BUTTON_XPATH)

    if is_error_popup_present(driver):
        clicar_elemento(driver, CANCELAR_BUTTON_XPATH)
        return "erro"
    
    log_info("Caso processado com sucesso! Enviado ao banco.")
    return "sucesso"

# Fluxos simplificados mantendo a lógica modularizada
def fluxo_dinamico_sistema(driver, resultado):
    campos = [
        ('bloco1', 'ctl00_ContentPlaceHolder1_f108ac1e'),
        ('verificador1', 'ctl00_ContentPlaceHolder1_66c0c8d5'),
        ('bloco2', 'ctl00_ContentPlaceHolder1_f6228836'),
        ('verificador2', 'ctl00_ContentPlaceHolder1_e0fea8f9'),
        ('bloco3', 'ctl00_ContentPlaceHolder1_2eda595d'),
        ('verificador3', 'ctl00_ContentPlaceHolder1_897d45bf')
    ]
    
    for campo, xpath in campos:
        valor = str(resultado.get(campo, '')) or ''
        preencher_campo(driver, f"//*[contains(@id,'{xpath}')][1]", valor)
    
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_e727e35f')][1]", "00010001")
    return valida_formulario(driver)

def fluxo_identifica_dinamico(driver, resultado):
    # Obtém o código de barras e extrai a origem a partir dos primeiros 8 caracteres
    codigo_de_barras = str(resultado.get('codigo_de_barras', '')) or ''
    
    if len(codigo_de_barras) < 8:
        log_info("Erro: código de barras insuficiente para determinar a origem.")
        return "erro"

    origem = codigo_de_barras[:8][-1]  # Pega o último caractere dos primeiros 8 caracteres

    # Preenche o campo correspondente com a origem
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_01a9bd3d')][1]", origem)

    # Valida o formulário após o preenchimento
    return valida_formulario(driver)


def fluxo_dinamico_intranet(driver, resultado):
    campos = [
        ('bloco1', 'ctl00_ContentPlaceHolder1_311cabb0'),
        ('verificador1', 'ctl00_ContentPlaceHolder1_38fa9bbe'),
        ('bloco2', 'ctl00_ContentPlaceHolder1_14a681a1'),
        ('verificador2', 'ctl00_ContentPlaceHolder1_7de6f1b6'),
        ('bloco3', 'ctl00_ContentPlaceHolder1_825a2e1c'),
        ('verificador3', 'ctl00_ContentPlaceHolder1_f55b72f7'),
        ('bloco4', 'ctl00_ContentPlaceHolder1_825b79c7'),
        ('verificador4', 'ctl00_ContentPlaceHolder1_0d6b5c79')
    ]

    for campo, xpath in campos:
        valor = str(resultado.get(campo, '')) or ''
        preencher_campo(driver, f"//*[contains(@id,'{xpath}')][1]", valor)

    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_e303d018')][1]", '001001')
    return valida_formulario(driver)

def fluxo_modelo(driver, resultado):
    modelo = str(resultado.get('modelo', '')) or '' 
    modelo_valido, modelo = validar_modelos(modelo)  

    if not modelo_valido and modelo == '':
        return "erro_modelo"

    elif not modelo_valido and modelo != '':
        preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_4b09144c')][1]", modelo)
        tratar_erro(driver, '5') 
        return "sucesso" 
    
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_4b09144c')][1]", modelo)
    return valida_formulario(driver)

def fluxo_pagina_1(driver, resultado):
    agencia = driver.find_element(By.XPATH, "//*[contains(@id,'ctl00_ContentPlaceHolder1_723f6103')][1]").get_attribute('value')

    conta = str(resultado.get('conta', '')).lstrip("0") or ''
    conta = re.sub(r'\D', '', conta)

    if str(agencia) in conta:
        conta = ''

    dac = str(resultado.get('dac', '')) or ''
    dac_verificado = calcula_digito_verificador(conta) if conta != '' else ''
    confianca_dac = resultado.get('confianca_conta', 0)
    if dac is not None and dac != '' and confianca_dac > 90:
        dac_batido = dac
    elif dac_verificado is not None and dac_verificado != '':
        dac_batido = dac_verificado
    else:
        dac_batido = ''

    cpf_cnpj_completo = str(resultado.get('cpf_cnpj', '')) or ''
    cpf_cnpj_completo = re.sub(r'\D', '', cpf_cnpj_completo)

    if len(cpf_cnpj_completo) in [9, 10, 11]:
        cpf_cnpj_completo = cpf_cnpj_completo.zfill(11)
        cpf_cnpj = cpf_cnpj_completo[:9]
        filial = ''
        controle = cpf_cnpj_completo[-2:]
    elif len(cpf_cnpj_completo) in [13, 14] and '60746948' not in cpf_cnpj_completo:
        cpf_cnpj_completo = cpf_cnpj_completo.zfill(14)
        cpf_cnpj = cpf_cnpj_completo[:8]
        filial = cpf_cnpj_completo[8:12]
        controle = cpf_cnpj_completo[-2:]
    elif len(cpf_cnpj_completo) == 15:
            cpf_cnpj_completo = cpf_cnpj_completo[-14:]
            cpf_cnpj = cpf_cnpj_completo[:8]
            filial = cpf_cnpj_completo[8:12]
            controle = cpf_cnpj_completo[-2:]
    else:
        cpf_cnpj = filial = controle = ''

    n_contrato = str(resultado.get('n_documento','')).lstrip("0") or ''
    n_contrato = re.sub(r'\D', '', n_contrato)
    n_contrato = re.sub(r'\d+0001\d{2}', '', n_contrato)

    processar, conta, cpf_cnpj, n_contrato = verificar_fluxo(resultado, conta, cpf_cnpj, n_contrato)
    if not processar:
        return "erro"

    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_e1b208d7')][1]", conta)
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_283391e4')][1]", dac_batido)
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_32a22056')][1]", cpf_cnpj)
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_e6ad7175')][1]", filial)
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_b778e558')][1]", controle)
    preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_3a5361b6')][1]", n_contrato)
    return valida_formulario(driver)

def fluxo_redigitacao_ncontrato(driver, resultado):
    n_contrato = str(resultado.get('n_documento', '')).lstrip("0") or ''
    n_contrato = re.sub(r'\D', '', n_contrato)
    n_contrato = re.sub(r'\d+0001\d{2}', '', n_contrato)

    if (n_contrato and n_contrato != ''):
        preencher_campo(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_474c7740')]", n_contrato)
    else:
        clicar_elemento(driver, "//*[contains(@id,'ctl00_ContentPlaceHolder1_4ce48ef2')]")
    return valida_formulario(driver)

fluxo_dinamico_sistema.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.

Instruções de Extração:

CÓDIGO DE BARRAS:
- Regra: Extrair o dado completo, separados em blocos e verificadores.
- Formato: Numérico, 42 a 50 caracteres.
- Localização: No topo da página
- Obrigatório: Sim.

Exemplo de retorno:
{
 "bloco1":"12345000",
 "confianca_bloco1": 90,
 "verificador1":"0", 
 "confianca_verificador1": 91,
 "bloco2":"1234500", 
 "confianca_bloco2": 95,
 "verificador2":"0", 
 "confianca_verificador2": 99,
 "bloco3":"1234512345123451234", 
 "confianca_bloco3": 96,
 "verificador3":"0", 
 "confianca_verificador3": 92,
 "bloco4":"12345000", 
 "confianca_bloco4": 98,
}"""

fluxo_identifica_dinamico.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.

Instruções de Extração:

CÓDIGO DE BARRAS:
- Regra: Extrair o dado completo, sem cortes.
- Formato: Numérico, 42 a 50 caracteres.
- Localização: No topo da página
- Obrigatório: Sim.

Exemplo de retorno:
{
 "codigo_de_barras": "123456781123456711234567891234567811234567",
 "confianca_codigo_barras": 100
}"""

fluxo_dinamico_intranet.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.

Instruções de Extração:

CÓDIGO DE BARRAS:
- Regra: Extrair o dado completo, separados em blocos e verificadores.
- Formato: Numérico, 42 a 50 caracteres.
- Localização: No topo da página
- Obrigatório: Sim.

Exemplo de retorno:
{
 "bloco1":"12345000",
 "confianca_bloco1": 90,
 "verificador1":"0", 
 "confianca_verificador1": 91,
 "bloco2":"1234500", 
 "confianca_bloco2": 95,
 "verificador2":"0", 
 "confianca_verificador2": 99,
 "bloco3":"123450000", 
 "confianca_bloco3": 96,
 "verificador3":"0", 
 "confianca_verificador3": 92,
 "bloco4":"12345000", 
 "confianca_bloco4": 98,
 "verificador4":"0", 
 "confianca_verificador4": 100,
 "bloco5":"123450"
 "confianca_bloco5": 90,
}"""

fluxo_modelo.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato do texto: Texto digitado terá maior confiança que texto manuscrito ilegível.
Contexto: A proximidade dos termos-chave ("MOD.:", etc.) ao valor extraído afeta a confiança. Ambiguidade reduz a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.
Instruções de Extração:

MODELO:
- Regra: Extrair o dado completo, sem cortes.
- Formato: Alfanumérico, 5 a 8 caracteres.
- Localização: Geralmente próximo ao termo 'MOD.:'
- Obrigatório: Sim.

Exemplo de retorno:
{
  "modelo": "PC007",
  "confianca_modelo": 80 
}"""

fluxo_pagina_1.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Preste atenção a variações de escrita e sintaxe para identificar a escrita manual. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato do texto: Informação digitada terá maior confiança que informação escrita ilegível.
Contexto: A proximidade dos termos-chave ("CONTA", "CPF/CNPJ", "Cédula de Crédito" e "Nº do Documento") ao valor extraído afeta a confiança. Ambiguidade reduz a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.

Instruções de Extração:

CONTA:

Regra: Extrair o dado numérico completo (sem caracteres adicionais).
Formato: 5 a 10 dígitos numéricos.
Localização: Próximo a "CONTA" ou "CONTA CORRENTE".
Obrigatório: Sim.
Exclusões: Não considerar números no formato de CPF ou CNPJ.

DAC:

Regra: Extrair o dígito da conta.
Formato: 1 dígito numérico.
Localização: Logo após a "CONTA" e próximo a "DIGITO".
Obrigatório: Sim.

CPF/CNPJ:

Regra: Extrair o primeiro CPF ou CNPJ. Se for CNPJ do Bradesco (lista abaixo), descartá-lo e procurar outro.
Lista de CNPJs do Bradesco: 60.746.948/0001-12 (Banco Bradesco S.A.).
Formato: Formato padrão de CPF ou CNPJ (11 dígitos para CPF, 14 dígitos para CNPJ).
Localização: Próximo a "CPF/CNPJ/MF".
Obrigatório: Sim.
Exclusões: Não considerar números que não correspondam ao formato padrão de CPF ou CNPJ.

NUMERO DO DOCUMENTO:

Regra: Extrair o número do documento. Priorizar a extração de números com 6 a 15 dígitos localizados no topo da página. Se não encontrado no topo, procurar em outra parte do documento, desconsiderando prefixos e sufixos alfanuméricos. Se for nota promissória, retornar ". Não considerar a palavra "CONTRATO" isoladamente. Atenção para "Cédula de Crédito" e "Nº do Documento" como indicadores de proximidade. Se múltiplos números com o formato especificado forem encontrados, retornar o primeiro encontrado.
Exclusões: 
- Não considerar números no formato de CPF ou CNPJ.
- Não considerar números que contenham hífen (`-`), como em RG ou outros documentos similares.
- Não considerar números que fazem parte da Conta.
Formato: Numérico, 6 a 15 dígitos.
Localização: Prioritariamente no topo da página. Se não encontrado, procurar em outra parte do documento. Geralmente próximo a "Cédula de Crédito" e "Nº do Documento".
Obrigatório: Sim.

VALOR:

Regra: Extrair o valor completo de "Valor Empréstimo" ou "Valor Total".
Formato: Numérico (Reais), com ponto separando a parte inteira da decimal.
Localização: Próximo a "Dt Operação" ou "Número Documento", ou em outros locais relevantes.
Obrigatório: Não.

Exemplo de Retorno:

{
  "conta": "12345",
  "confianca_conta": 95,
  "dac": "1",
  "confianca_dac": 90,
  "cpf_cnpj": "123.456.789-00",
  "confianca_cpf_cnpj": 90,
  "n_documento": "654321",
  "confianca_n_documento": 80,
  "valor": "150000.00",
  "confianca_valor": 98
}"""

fluxo_redigitacao_ncontrato.prompt = """Como um agente de extração de dados, você receberá uma imagem como entrada. Sua tarefa é extrair as informações solicitadas a seguir, obedecendo rigorosamente às regras. Retorne os dados em formato JSON, incluindo um campo "confiança" (0-100%) para cada informação extraída. Se a informação não for encontrada, retorne uma string vazia para o campo correspondente. Preste atenção a variações de escrita e sintaxe para identificar a escrita manual. Análise Visual.
A confiança (0-100%) dependerá de:

Clareza da imagem: Imagens nítidas e bem iluminadas aumentam a confiança.
Formato do texto: Informação digitada terá maior confiança que informação escrita ilegível.
Contexto: A proximidade dos termos-chave ("Cédula de Crédito" e "Nº do Documento".) ao valor extraído afeta a confiança. Ambiguidade reduz a confiança.
Formato dos dados: A correspondência ao formato esperado (número de dígitos, etc.) aumenta a confiança.

Instruções de Extração:

NUMERO DO DOCUMENTO:

Regra: Extrair o número do documento. Priorizar a extração de números com 6 a 15 dígitos localizados no topo da página. Se não encontrado no topo, procurar em outra parte do documento, desconsiderando prefixos e sufixos alfanuméricos. Se for nota promissória, retornar ". Não considerar a palavra "CONTRATO" isoladamente. Atenção para "Cédula de Crédito" e "Nº do Documento" como indicadores de proximidade. Se múltiplos números com o formato especificado forem encontrados, retornar o primeiro encontrado.
Exclusões: 
- Não considerar números no formato de CPF ou CNPJ.
- Não considerar números que contenham hífen (`-`), como em RG ou outros documentos similares.
- Não considerar números que fazem parte da Conta.
Formato: Numérico, 6 a 15 dígitos.
Localização: Prioritariamente no topo da página. Se não encontrado, procurar em outra parte do documento. Geralmente próximo a "Cédula de Crédito" e "Nº do Documento".
Obrigatório: Sim.

Exemplo de retorno:
{
  "n_documento": "987451284",
  "confianca_n_documento": 80,
}"""

fluxo_map = {
    'CONTRATO - Dinamico Sistema': (fluxo_dinamico_sistema, '4'),
    'CONTRATO - Identifica Dinamico': (fluxo_identifica_dinamico, '4'),
    'CONTRATO - Dinamico Intranet': (fluxo_dinamico_intranet, '4'),
    'CONTRATO - MODELO': (fluxo_modelo, '1'),
    'CONTRATO - Página 1': (fluxo_pagina_1, '2'),
    'CONTRATO - REDIGITAÇÃO NCONTRATO': (fluxo_redigitacao_ncontrato, '6')
}

async def processar_fluxo(driver, transaction_item):
    fluxo_info = fluxo_map.get(transaction_item, None)

    if fluxo_info:
        fluxo_func, codigo_erro = fluxo_info
        return await processar_fluxo_generico(driver, fluxo_func, codigo_erro)
    else:
        log_info(f"Nenhum fluxo encontrado para: {transaction_item}")
        return False

