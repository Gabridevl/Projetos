import os
import shutil
import time
from datetime import datetime, timedelta
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, StaleElementReferenceException

from utils.config import log_info, configure_logging

configure_logging()

def valida_elemento_clicavel(driver, xpath, timeout):
    try:
        WebDriverWait(driver, int(timeout)).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        return True
    except TimeoutException:
        log_info(f"Elemento clicável não encontrado: {xpath}")
        return False

def valida_elemento_visivel(driver, xpath, timeout):
    try:
        WebDriverWait(driver, int(timeout)).until(EC.visibility_of_element_located((By.XPATH, xpath)))
        return True
    except TimeoutException:
        log_info(f"Elemento visível não encontrado: {xpath}")
        return False

def is_error_popup_present(driver):
    return valida_elemento_visivel(driver, "//*[@id='ctl00_ContentPlaceHolder1_ValidationPanel']", 5)

def tratar_erro(driver, dinamico, max_tentativas=5, timeout=10):
    CANCELAR_BUTTON_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_Button_ValidationCancel']"
    STATUS_PANEL_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_SetStatusPanel']"
    STATUS_BUTTON_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_Button_Status']"
    MOTIVO_OPTION_XPATH = f"//*[@id='ctl00_ContentPlaceHolder1_StatusLB']/option[{dinamico}]"
    OK_BUTTON_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_Button_StatusOk']"
    STATUS_LABEL_XPATH = "//*[@id='ctl00_ContentPlaceHolder1_StatusLabel']"
    NEXT_DOCUMENT_XPATH = "//*[contains(@id,'ctl00_ContentPlaceHolder1_Button_NextDocument')]"

    if is_error_popup_present(driver):
        log_info("Popup de erro detectado. Tentando fechar.")
        try:
            driver.find_element(By.XPATH, CANCELAR_BUTTON_XPATH).click()
        except ElementClickInterceptedException:
            log_info("Não foi possível clicar no botão de cancelar. Tentando novamente.")
            WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, CANCELAR_BUTTON_XPATH))).click()

    tentativas = 0
    while not valida_elemento_visivel(driver, STATUS_PANEL_XPATH, 1):
        if tentativas >= max_tentativas:
            log_info(f"Não foi possível abrir o painel de status após {max_tentativas} tentativas")
            raise TimeoutException(f"Não foi possível abrir o painel de status após {max_tentativas} tentativas")
        log_info(f"Tentativa {tentativas + 1} de abrir o painel de status")
        driver.find_element(By.XPATH, STATUS_BUTTON_XPATH).click()
        tentativas += 1

    try:
        WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, MOTIVO_OPTION_XPATH))).click()
        WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, OK_BUTTON_XPATH))).click()
    except StaleElementReferenceException:
        log_info("Elemento ficou obsoleto. Tentando novamente.")
        WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, MOTIVO_OPTION_XPATH))).click()
        WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, OK_BUTTON_XPATH))).click()

    if is_error_popup_present(driver):
        driver.find_element(By.XPATH, CANCELAR_BUTTON_XPATH).click()

    if verifica_ultima_pagina(driver) and valida_elemento_visivel(driver, STATUS_LABEL_XPATH, 3):
        WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.XPATH, NEXT_DOCUMENT_XPATH))).click()

    log_info("Tratamento de erro concluído com sucesso")

def calcula_digito_verificador(conta):
    pesos = [2, 7, 6, 5, 4, 3, 2]
    conta_zero = str(conta).zfill(7)
    
    soma = sum(int(digito) * peso for digito, peso in zip(conta_zero, pesos))
    resto = soma % 11
    dv = 11 - resto if resto != 0 else 0

    return str(dv)

def verifica_ultima_pagina(driver):
    paginas_xpath = "//*[@id='ctl00_ContentPlaceHolder1_lblStatus']"
    pagina_atual, total_paginas = driver.find_element(By.XPATH, paginas_xpath).text.split('/')

    pagina_atual = int(pagina_atual)
    total_paginas = int(total_paginas)

    return pagina_atual == total_paginas

def verificar_disponibilidade_portal(driver):
    agora = datetime.now()
    inicio_indisponibilidade = agora.replace(hour=23, minute=45, second=0, microsecond=0)
    fim_indisponibilidade = (agora + timedelta(days=1)).replace(hour=0, minute=35, second=0, microsecond=0)

    if inicio_indisponibilidade <= agora <= fim_indisponibilidade:
        log_info("Portal em período de indisponibilidade. Iniciando procedimento de espera.")

        # Calcular tempo de espera
        tempo_espera = (fim_indisponibilidade - agora).total_seconds()
        minutos_espera = int((tempo_espera + 59) // 60)

        log_info(f"Aguardando {minutos_espera} minutos até a disponibilidade do portal.")
        
        tempo_total_espera = 0 
        for i in range(minutos_espera):
            time.sleep(60)
            tempo_total_espera += 1
            if (i + 1) % 5 == 0:
                driver.refresh()
                log_info(f"Ainda aguardando. {minutos_espera - i - 1} minutos restantes.")
                
            if tempo_total_espera >= 20:  # Verifica se já se passaram 20 minutos
                log_info("20 minutos de espera atingidos. Reiniciando o processo.")
                return True  # Reinicia o processo

        log_info("Período de indisponibilidade encerrado. Retomando operações.")
        return True

    return False

def limpar_pasta_downloads():
    # Obtém o diretório de downloads do usuário
    downloads_dir = os.path.expanduser("~/Downloads")
    
    if not os.path.exists(downloads_dir):
        log_info("Pasta de downloads não encontrada.")
        return
    
    # Itera sobre os itens na pasta de downloads e remove apenas arquivos
    for item in os.listdir(downloads_dir):
        item_path = os.path.join(downloads_dir, item)
        
        try:
            if os.path.isfile(item_path):
                os.remove(item_path)  # Remove arquivos
                log_info(f"Arquivo {item} removido com sucesso.")
            elif os.path.isdir(item_path):
                shutil.rmtree(item_path)  # Remove pastas e seu conteúdo
                log_info(f"Pasta {item} removida com sucesso.")
        except Exception as e:
            log_info(f"Erro ao remover {item}")
