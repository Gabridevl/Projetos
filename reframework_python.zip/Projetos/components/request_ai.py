import base64
import json
import re
import shutil
import aiohttp
import os
import time
import sys
from PIL import Image
from utils.config import log_info, log_error, configure_logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

configure_logging()

def esperar_arquivo_completo(caminho_arquivo, timeout=10):
    """
    Aguarda até que não existam arquivos incompletos no diretório, por até 10 segundos.
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        arquivos_incompletos = [f for f in os.listdir(caminho_arquivo) if f.endswith('.crdownload') or f.endswith('.tmp')]
        if not arquivos_incompletos:
            return True
        time.sleep(1)
    log_error("Timeout ao esperar arquivos incompletos.")
    return False

def download_image(driver):
    # Caminho do diretório de downloads padrão
    downloads_dir = os.path.expanduser("~/Downloads")
    if not esperar_arquivo_completo(downloads_dir):
        raise TimeoutError("Arquivos incompletos não foram finalizados a tempo.")

    # Verifica arquivos TIFF
    tiff_files = [f for f in os.listdir(downloads_dir) if f.endswith('.tiff')]
    if not tiff_files:
        log_error("Nenhum arquivo TIFF encontrado na pasta de downloads.")
        return tirar_screenshot_com_alternativa(driver)
    
    # Pega o TIFF mais recente
    latest_tiff = max([os.path.join(downloads_dir, f) for f in tiff_files], key=os.path.getmtime)
    
    # Diretório para salvar arquivos processados
    project_dir = os.path.dirname(os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__)))
    processed_dir = os.path.join(project_dir, "arquivos_processados")
    os.makedirs(processed_dir, exist_ok=True)

    base_filename = f"image_downloaded"
    png_path = os.path.join(project_dir, f"{base_filename}.png")

    try:
        with Image.open(latest_tiff) as img:
            img.convert("RGBA").save(png_path, "PNG")
        os.remove(latest_tiff)

        # Copiar o arquivo PNG para a pasta de processados
        processed_png_path = os.path.join(processed_dir, f"{base_filename}.png")
        shutil.copy2(png_path, processed_png_path)
        time.sleep(2)
        os.remove(png_path)
    except Exception as e:
        log_error(f"Erro ao converter TIFF para PNG: {e}")
        raise

    log_info(f"Imagem salva em {processed_png_path}")
    return processed_png_path # Retorna o caminho completo e o nome base sem extensão


def tirar_screenshot_com_alternativa(driver):
    """
    Volta para a tela anterior até encontrar o elemento de referência e, então, tira uma captura de tela.
    """
    # Diretório para salvar arquivos processados
    project_dir = os.path.dirname(os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__)))
    processed_dir = os.path.join(project_dir, "arquivos_processados")
    os.makedirs(processed_dir, exist_ok=True)

    # Nome do arquivo de captura de tela com timestamp
    base_filename = f"screenshot"
    screenshot_path = os.path.join(processed_dir, f"{base_filename}.png")

    # Loop para voltar até encontrar o elemento de referência
    max_attempts = 5
    attempts = 0
    referencia_xpath = "//*[contains(@id, 'imgAdvancedImageControl')]"
    while attempts < max_attempts:
        try:
            # Tenta encontrar o elemento de referência
            WebDriverWait(driver, 5).until(EC.visibility_of_element_located((By.XPATH, referencia_xpath)))
            element = driver.find_element(By.XPATH, referencia_xpath)
            element.screenshot(screenshot_path)
            log_info(f"Captura de tela salva em {screenshot_path} como alternativa ao download.")
            return screenshot_path
        except TimeoutException:
            # Se o elemento não foi encontrado, volta para a página anterior
            log_info("Elemento de referência não encontrado. Voltando para a página anterior.")
            driver.back()
            time.sleep(2)
            attempts += 1

    # Se não encontrar o elemento após várias tentativas, loga erro e salva captura de tela
    driver.save_screenshot(screenshot_path)
    log_info(f"Captura de tela de fallback salva em {screenshot_path}")
    return screenshot_path

def imagem_para_base64(image_path):
    """
    Converte uma imagem PNG para base64.

    Args:
        image_path (str): Caminho da imagem.

    Returns:
        str: String base64 da imagem.
    """
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")
    except Exception as e:
        log_error(f"Erro ao converter imagem para base64: {e}")
        return None

async def fazer_requisicao_api_async(session, url, payload):
    """
    Função assíncrona para fazer requisições à API.
    """
    try:
        async with session.post(url, json=payload) as response:
            if response.status == 200:
                return await response.json()
            else:
                log_error(f"Erro na requisição: Status {response.status}")
                return None
    except Exception as e:
        log_error(f"Erro ao fazer requisição assíncrona: {e}")
        return None


async def processar_requisicao_async(prompt, driver):
    """
    Captura a imagem, converte para base64 e envia para ambas as APIs simultaneamente.
    """
    try:
        image_path = download_image(driver)
        base64_image = imagem_para_base64(image_path)
        if not base64_image:
            log_error("Falha ao converter imagem para base64.")
            return []

        payload_google = {
            "prompt": prompt,
            "temperature": 0,
            "apiKey": "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",
            "idUsuario": "10",
            "modelName": "gemini-1.5-flash-002",
            "base64Archive": base64_image,
        }       

        url_google = "https://apiSbk.sbk.com.br/inteligencia-artificial-generativa/3"

        async with aiohttp.ClientSession() as session:
            response_google = await fazer_requisicao_api_async(session, url_google, payload_google)

        return response_google, base64_image
    except Exception as e:
        log_error(f"Erro no processamento da requisição assíncrona: {e}")
        return []

async def processar_requisicao(prompt, driver):
    """
    Wrapper síncrono para a função assíncrona.
    """
    try:
        response, base64_image = await processar_requisicao_async(prompt, driver)

        if response and "message" in response:
            message_str = response["message"]
            message_str_cleaned = re.sub(r"```json|```|\n", "", message_str).strip()
            try:
                message_dict = json.loads(message_str_cleaned)
                log_info(f"API GOOGLE: {message_dict}")
                resultado = message_dict
            except json.JSONDecodeError:
                log_error("Erro ao decodificar JSON {""retorno"": ""vazio""}")
                resultado = "{""retorno"": ""vazio""}"
        else:
            log_info("Resposta da API inválida ou vazia {""retorno"": ""vazio""}")
            resultado = "{""retorno"": ""vazio""}"
        return resultado, base64_image
    except Exception as e:
        log_error(f"Erro no processamento da requisição síncrona: {e}")
        return "{""retorno"": ""vazio""}"