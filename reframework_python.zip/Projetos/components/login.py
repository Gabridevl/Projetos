from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from utils.config import log_info, log_error, configure_logging

configure_logging()

def esperar_elemento(driver, xpath, timeout=10):
    """Função genérica para aguardar um elemento ser carregado."""
    try:
        elemento = WebDriverWait(driver, timeout).until(EC.presence_of_element_located((By.XPATH, xpath)))
        return elemento
    except TimeoutException:
        log_error(f"Elemento não encontrado após {timeout} segundos: {xpath}")
        return None

def realizar_login(driver, username, password):
    """
    Realiza o login em uma página específica usando o WebDriver.

    Args:
        driver: Instância do WebDriver do navegador.
        username (str): Nome de usuário para login.
        password (str): Senha para login.

    Returns:
        bool: True se o login for bem-sucedido, False caso contrário.
    """
    login_xpath = "//*[@id='ctl00_ContentPlaceHolder1_AthicAuthenticationControl_loginTextBox']"
    password_xpath = "//*[@id='ctl00_ContentPlaceHolder1_AthicAuthenticationControl_passwordTextBox']"
    submit_xpath = "//*[@id='ctl00_ContentPlaceHolder1_AthicAuthenticationControl_submitButton']"
    success_xpath = "//*[@id='ctl00_ContentPlaceHolder1_titleLabel']"

    # Espera pelo campo de login
    elemento_login = esperar_elemento(driver, login_xpath)
    if not elemento_login:
        log_error("Erro: Elemento de login não encontrado.")
        return False

    try:
        # Localiza e interage com os elementos de login
        username_field = driver.find_element(By.XPATH, login_xpath)
        password_field = driver.find_element(By.XPATH, password_xpath)
        login_button = driver.find_element(By.XPATH, submit_xpath)

        username_field.send_keys(username)
        password_field.send_keys(password)
        login_button.click()

        # Aguarda até que o login seja bem-sucedido
        elemento_sucesso = esperar_elemento(driver, success_xpath)
        if elemento_sucesso:
            log_info("Login bem-sucedido.")
            return True
        else:
            log_error("Erro: Não foi possível completar o login.")
            return False

    except NoSuchElementException as e:
        log_error(f"Erro ao encontrar um dos elementos de login: {e}")
        return False
    except TimeoutException as e:
        log_error(f"Tempo de carregamento excedido ao tentar fazer login: {e}")
        return False
