import os
from selenium import webdriver
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.common.exceptions import WebDriverException
from utils.config import log_info, log_error, configure_logging

configure_logging()

def obter_driver_path(driver_name="msedgedriver.exe"):
    """Obtém o caminho do driver com base no nome do driver especificado."""
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    driver_path = os.path.join(base_dir, driver_name)
    if not os.path.exists(driver_path):
        log_error(f"{driver_name} não encontrado no caminho: {driver_path}")
        return None
    return driver_path

def abrir_navegador(url, driver_type="msedge", driver_path=None):
    """
    Abre o navegador especificado no URL fornecido.

    Args:
        url (str): URL a ser acessada pelo navegador.
        driver_type (str): Tipo do navegador (edge, chrome, firefox).
        driver_path (str): Caminho opcional para o executável do WebDriver.

    Returns:
        WebDriver: Instância do WebDriver do navegador escolhido.
    """
    # Define o driver_path se não for fornecido
    if not driver_path:
        driver_path = obter_driver_path(driver_type + "driver.exe")
    
    # Se não for possível obter o caminho do driver, retorna None
    if not driver_path:
        return None

    # Configurações de opções para o navegador
    if driver_type == "msedge":
        options = EdgeOptions()
        options.add_argument('--log-level=3')
        service = EdgeService(executable_path=driver_path)
        driver = webdriver.Edge(service=service, options=options)
    elif driver_type == "chrome":
        options = ChromeOptions()
        options.add_argument('--log-level=3')
        service = ChromeService(executable_path=driver_path)
        driver = webdriver.Chrome(service=service, options=options)
    elif driver_type == "firefox":
        options = FirefoxOptions()
        options.set_headless(True)  # Usar sem cabeça (opcional)
        service = FirefoxService(executable_path=driver_path)
        driver = webdriver.Firefox(service=service, options=options)
    else:
        log_error(f"Navegador {driver_type} não suportado.")
        return None

    try:
        driver.maximize_window()
        driver.get(url)
        log_info(f"Navegador {driver_type} aberto em: {url}")
        return driver
    except WebDriverException as e:
        log_error(f"Erro ao abrir o navegador {driver_type}: {e}")
        return None
